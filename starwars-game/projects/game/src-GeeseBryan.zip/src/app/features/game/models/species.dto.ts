export interface SpeciesDto {
  id: number | undefined;
  name: string;
}
