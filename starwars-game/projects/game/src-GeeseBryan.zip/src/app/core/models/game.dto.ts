export interface GameDto {
  id: number;
  title: number;
  success: boolean;
}
